from flask import * 
  
app = Flask(__name__) 
@app.route('/')
def home():  
    return "Home";  

@app.route('/levels',methods = ['POST'])  
def levels():  
    num_of_levels=int(request.form['levels'])  
    if num_of_levels>0 and num_of_levels<=5:
        session['levels']=num_of_levels
        return render_template('basket_name.html',levels=num_of_levels)
    else:
        return("Number of Levels Cannot Exceed the Limit" )    

@app.route('/baskets',methods = ['POST'])  
def baskets():
    basket_names=[]
    levels=session.get('levels')
    for i in range(1,levels+1):
        basket_name="basket_"+str(i)
        basket_name=request.form[basket_name]
        basket_names.append(basket_name)
    session['basket_names']=basket_names
    return render_template('items.html',basket_names=basket_names)

@app.route('/items',methods = ['POST'])  
def items():
    import pymongo,json
    from bson import json_util, ObjectId
    client=pymongo.MongoClient("mongodb://localhost:27017")
    db=client['local_database']
    collection=db['database_collection_1']
    input_dict={}
    basket_names=session.get('basket_names')
    for i in basket_names:
        items=request.form[i]
        items_list=items.split(",")
        input_dict[i]=items_list
    collection.insert_one(input_dict)
    return json.loads(json_util.dumps(input_dict))    

if __name__ == "__main__":
    app.secret_key = 'super secret key'
    app.config['SESSION_TYPE'] = 'filesystem'
    app.debug = True
    app.run()